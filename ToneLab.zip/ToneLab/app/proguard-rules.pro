# Reglas ProGuard/R8 de ToneLab (vacías en la v0.1; minificación desactivada).

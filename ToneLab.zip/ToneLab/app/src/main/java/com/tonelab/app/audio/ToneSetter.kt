package com.tonelab.app.audio

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import android.provider.Settings
import java.io.File

enum class ToneKind(val label: String, val type: Int, val directory: String) {
    RINGTONE("Tono de llamada", RingtoneManager.TYPE_RINGTONE, Environment.DIRECTORY_RINGTONES),
    NOTIFICATION("Notificación", RingtoneManager.TYPE_NOTIFICATION, Environment.DIRECTORY_NOTIFICATIONS),
    ALARM("Alarma", RingtoneManager.TYPE_ALARM, Environment.DIRECTORY_ALARMS)
}

sealed class ToneResult {
    object Success : ToneResult()
    object NeedsPermission : ToneResult()
    data class Failure(val message: String) : ToneResult()
}

object ToneSetter {

    fun permissionIntent(context: Context): Intent =
        Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${context.packageName}"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    /** Publica el archivo en MediaStore (carpeta Ringtones/Notifications/Alarms) y lo fija como predeterminado. */
    fun apply(context: Context, file: File, title: String, kind: ToneKind): ToneResult {
        if (!Settings.System.canWrite(context)) return ToneResult.NeedsPermission
        return try {
            val ext = file.extension.lowercase()
            val safeTitle = title.replace(Regex("[\\\\/:*?\"<>|]"), "_").ifBlank { "ToneLab" }
            val values = ContentValues().apply {
                put(MediaStore.Audio.Media.DISPLAY_NAME, "$safeTitle.$ext")
                put(MediaStore.Audio.Media.TITLE, safeTitle)
                put(MediaStore.Audio.Media.MIME_TYPE, mimeFor(ext))
                put(MediaStore.Audio.Media.RELATIVE_PATH, kind.directory)
                put(MediaStore.Audio.Media.IS_RINGTONE, kind == ToneKind.RINGTONE)
                put(MediaStore.Audio.Media.IS_NOTIFICATION, kind == ToneKind.NOTIFICATION)
                put(MediaStore.Audio.Media.IS_ALARM, kind == ToneKind.ALARM)
                put(MediaStore.Audio.Media.IS_MUSIC, false)
                put(MediaStore.Audio.Media.IS_PENDING, 1)
            }
            val resolver = context.contentResolver
            val collection = MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            val uri = resolver.insert(collection, values)
                ?: return ToneResult.Failure("No se pudo crear el archivo en el sistema")
            resolver.openOutputStream(uri)?.use { out ->
                file.inputStream().use { it.copyTo(out) }
            } ?: return ToneResult.Failure("No se pudo escribir el archivo")
            values.clear()
            values.put(MediaStore.Audio.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            RingtoneManager.setActualDefaultRingtoneUri(context, kind.type, uri)
            ToneResult.Success
        } catch (e: Exception) {
            ToneResult.Failure(e.message ?: "Error desconocido")
        }
    }

    private fun mimeFor(ext: String) = when (ext) {
        "wav" -> "audio/x-wav"
        "mp3" -> "audio/mpeg"
        "m4a", "mp4" -> "audio/mp4"
        "aac" -> "audio/aac"
        "ogg", "oga" -> "audio/ogg"
        "flac" -> "audio/flac"
        else -> "audio/*"
    }
}

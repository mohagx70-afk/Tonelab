package com.tonelab.app.data

enum class Kind { IMPORTED, TONE }

data class AudioItem(
    val id: String,
    val name: String,
    val fileName: String,
    val kind: Kind,
    val durationMs: Long,
    val createdAt: Long
)

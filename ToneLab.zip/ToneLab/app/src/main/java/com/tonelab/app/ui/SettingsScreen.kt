package com.tonelab.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.tonelab.app.AppViewModel
import com.tonelab.app.data.Kind

@Composable
fun SettingsScreen(vm: AppViewModel) {
    val dark by vm.darkTheme.collectAsState()
    val items by vm.repo.items.collectAsState()
    // Se recalcula cuando cambia la biblioteca
    val (fileCount, bytes) = remember(items) { vm.repo.storageInfo() }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            "Ajustes",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold
        )

        SettingsCard {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text("Tema oscuro", style = MaterialTheme.typography.titleMedium)
                    Text(
                        if (dark) "Activado" else "Se usa el tema claro",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(checked = dark, onCheckedChange = { vm.setDarkTheme(it) })
            }
        }

        SettingsCard {
            Text("Archivos guardados", style = MaterialTheme.typography.titleMedium)
            Text(
                "$fileCount archivos · ${formatBytes(bytes)}",
                style = MaterialTheme.typography.bodyMedium
            )
            Text(
                "Ubicación interna de la app:\n${vm.repo.storagePath()}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (items.isNotEmpty()) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    items.forEach { item ->
                        val size = vm.repo.fileOf(item).length()
                        Row(Modifier.fillMaxWidth()) {
                            Text(
                                (if (item.kind == Kind.TONE) "Tono · " else "Audio · ") + item.name,
                                style = MaterialTheme.typography.bodySmall,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                            Text(formatBytes(size), style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }

        SettingsCard {
            Text("Acerca de", style = MaterialTheme.typography.titleMedium)
            Text(
                "ToneLab 0.1.0. Funciona sin cuentas, sin servidores y sin conexión a Internet.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun SettingsCard(content: @Composable () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) { content() }
    }
}

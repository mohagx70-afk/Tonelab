package com.tonelab.app.data

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/**
 * Biblioteca local: los archivos viven en filesDir/audio y el índice en library.json.
 * Todo está detrás de esta clase, de modo que más adelante se puede sustituir por
 * Room o por una fuente remota (biblioteca comunitaria) sin tocar la interfaz.
 */
class LibraryRepository(private val context: Context) {

    private val dir = File(context.filesDir, "audio").apply { mkdirs() }
    private val indexFile = File(context.filesDir, "library.json")

    private val _items = MutableStateFlow(load())
    val items: StateFlow<List<AudioItem>> = _items

    fun fileOf(item: AudioItem): File = File(dir, item.fileName)

    fun newFile(extension: String): File =
        File(dir, UUID.randomUUID().toString() + "." + extension)

    suspend fun import(uri: Uri): AudioItem? = withContext(Dispatchers.IO) {
        val resolver = context.contentResolver
        var displayName = "Audio"
        resolver.query(uri, null, null, null, null)?.use { c ->
            val col = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (c.moveToFirst() && col >= 0) displayName = c.getString(col) ?: displayName
        }
        val ext = displayName.substringAfterLast('.', "").lowercase().ifBlank { "m4a" }
        val baseName = displayName.substringBeforeLast('.', displayName)
        val target = newFile(ext)
        try {
            resolver.openInputStream(uri)?.use { input ->
                target.outputStream().use { input.copyTo(it) }
            } ?: return@withContext null
            val duration = readDuration(target)
            if (duration <= 0) {
                target.delete()
                return@withContext null
            }
            val item = AudioItem(
                id = UUID.randomUUID().toString(),
                name = baseName,
                fileName = target.name,
                kind = Kind.IMPORTED,
                durationMs = duration,
                createdAt = System.currentTimeMillis()
            )
            add(item)
            item
        } catch (e: Exception) {
            target.delete()
            null
        }
    }

    fun addTone(file: File, name: String, durationMs: Long): AudioItem {
        val item = AudioItem(
            id = UUID.randomUUID().toString(),
            name = name,
            fileName = file.name,
            kind = Kind.TONE,
            durationMs = durationMs,
            createdAt = System.currentTimeMillis()
        )
        add(item)
        return item
    }

    fun rename(id: String, newName: String) {
        _items.value = _items.value.map { if (it.id == id) it.copy(name = newName) else it }
        persist()
    }

    fun delete(id: String) {
        val item = _items.value.firstOrNull { it.id == id } ?: return
        fileOf(item).delete()
        _items.value = _items.value.filter { it.id != id }
        persist()
    }

    /** Número de archivos y bytes ocupados. */
    fun storageInfo(): Pair<Int, Long> {
        val files = dir.listFiles()?.filter { it.isFile } ?: emptyList()
        return files.size to files.sumOf { it.length() }
    }

    fun storagePath(): String = dir.absolutePath

    private fun add(item: AudioItem) {
        _items.value = listOf(item) + _items.value
        persist()
    }

    private fun readDuration(file: File): Long {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(file.absolutePath)
            r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } catch (e: Exception) {
            0L
        } finally {
            r.release()
        }
    }

    private fun persist() {
        val arr = JSONArray()
        _items.value.forEach {
            arr.put(
                JSONObject()
                    .put("id", it.id)
                    .put("name", it.name)
                    .put("fileName", it.fileName)
                    .put("kind", it.kind.name)
                    .put("durationMs", it.durationMs)
                    .put("createdAt", it.createdAt)
            )
        }
        indexFile.writeText(arr.toString())
    }

    private fun load(): List<AudioItem> {
        if (!indexFile.exists()) return emptyList()
        return try {
            val arr = JSONArray(indexFile.readText())
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                AudioItem(
                    id = o.getString("id"),
                    name = o.getString("name"),
                    fileName = o.getString("fileName"),
                    kind = Kind.valueOf(o.getString("kind")),
                    durationMs = o.getLong("durationMs"),
                    createdAt = o.getLong("createdAt")
                )
            }.filter { File(dir, it.fileName).exists() }
        } catch (e: Exception) {
            emptyList()
        }
    }
}

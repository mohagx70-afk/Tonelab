package com.tonelab.app.audio

import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.io.File

/** Reproductor sencillo con soporte para reproducir solo un tramo (previsualización). */
class AudioPlayer {
    private var mediaPlayer: MediaPlayer? = null
    private val handler = Handler(Looper.getMainLooper())

    /** Clave de lo que suena ahora (id del audio o "preview"), o null si está parado. */
    var playingKey by mutableStateOf<String?>(null)
        private set
    var positionMs by mutableLongStateOf(0L)
        private set

    fun play(key: String, file: File, startMs: Long = 0, endMs: Long? = null) {
        stop()
        val p = MediaPlayer()
        try {
            p.setDataSource(file.absolutePath)
            p.prepare()
            p.seekTo(startMs.toInt())
            p.start()
        } catch (e: Exception) {
            p.release()
            return
        }
        mediaPlayer = p
        playingKey = key
        positionMs = startMs
        p.setOnCompletionListener { stop() }

        val ticker = object : Runnable {
            override fun run() {
                val current = mediaPlayer ?: return
                val pos = try { current.currentPosition.toLong() } catch (e: Exception) { return }
                positionMs = pos
                if (endMs != null && pos >= endMs) {
                    stop()
                    return
                }
                handler.postDelayed(this, 40)
            }
        }
        handler.post(ticker)
    }

    fun stop() {
        handler.removeCallbacksAndMessages(null)
        val p = mediaPlayer
        mediaPlayer = null
        if (p != null) {
            try { p.stop() } catch (_: Exception) {}
            p.release()
        }
        playingKey = null
    }

    fun release() = stop()
}

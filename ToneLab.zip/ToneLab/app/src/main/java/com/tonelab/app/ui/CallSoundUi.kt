package com.tonelab.app.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.tonelab.app.AppViewModel
import com.tonelab.app.audio.AnswerSoundPlayer
import com.tonelab.app.data.AudioItem

fun hasPhonePermission(context: Context): Boolean =
    ContextCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) ==
        PackageManager.PERMISSION_GRANTED

/** Devuelve una función que pide el permiso de teléfono y avisa del resultado. */
@Composable
fun rememberPhonePermissionRequester(onResult: (Boolean) -> Unit): () -> Unit {
    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission(),
        onResult
    )
    return { launcher.launch(Manifest.permission.READ_PHONE_STATE) }
}

/** Tarjeta de Ajustes para configurar el sonido que suena al coger una llamada. */
@Composable
fun CallSoundCard(vm: AppViewModel) {
    val context = LocalContext.current
    val items by vm.repo.items.collectAsState()
    var hasPermission by remember { mutableStateOf(hasPhonePermission(context)) }
    var picking by remember { mutableStateOf(false) }
    val request = rememberPhonePermissionRequester { hasPermission = it }
    val selected = items.firstOrNull { it.id == vm.answer.itemId }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text("Sonido al coger la llamada", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Suena en tu móvil cuando descuelgas una llamada entrante. La otra persona no lo oye.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(
                    checked = vm.answer.enabled && selected != null,
                    onCheckedChange = { on ->
                        if (on && selected == null) {
                            Toast.makeText(context, "Elige primero un sonido", Toast.LENGTH_SHORT).show()
                        } else {
                            vm.answer.setEnabled(on)
                            if (on && !hasPermission) request()
                        }
                    }
                )
            }

            Text("Sonido elegido: ${selected?.name ?: "ninguno"}")

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { picking = true }) { Text("Elegir") }
                OutlinedButton(
                    enabled = selected != null,
                    onClick = { selected?.let { AnswerSoundPlayer.play(vm.repo.fileOf(it)) } }
                ) { Text("Probar") }
                if (selected != null) {
                    TextButton(onClick = { vm.answer.clear() }) { Text("Quitar") }
                }
            }

            if (!hasPermission) {
                Text(
                    "Falta el permiso de teléfono, necesario para detectar cuándo descuelgas.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error
                )
                Button(onClick = request) { Text("Conceder permiso") }
            }

            Text(
                "Si no suena, desactiva el ahorro de batería para ToneLab. " +
                    "Usa sonidos cortos: se cortan a los 8 segundos.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            OutlinedButton(onClick = {
                context.startActivity(
                    Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }) { Text("Abrir ajustes de batería") }
        }
    }

    if (picking) {
        PickSoundDialog(
            items = items,
            onPick = { item ->
                vm.answer.select(item, vm.repo.fileOf(item))
                picking = false
                if (!hasPermission) request()
            },
            onDismiss = { picking = false }
        )
    }
}

@Composable
private fun PickSoundDialog(items: List<AudioItem>, onPick: (AudioItem) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Elige el sonido") },
        text = {
            if (items.isEmpty()) {
                Text("Tu biblioteca está vacía. Importa o crea un audio primero.")
            } else {
                Column(
                    modifier = Modifier
                        .heightIn(max = 320.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    items.forEach { item ->
                        TextButton(
                            onClick = { onPick(item) },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text(item.name) }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

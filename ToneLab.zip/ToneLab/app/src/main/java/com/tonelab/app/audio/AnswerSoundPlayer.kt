package com.tonelab.app.audio

import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import java.io.File

/** Reproduce un sonido corto (máximo 8 s) y avisa con [onDone] cuando termina o falla. */
object AnswerSoundPlayer {

    fun play(file: File, onDone: () -> Unit = {}) {
        val handler = Handler(Looper.getMainLooper())
        val player = MediaPlayer()
        var finished = false

        fun finish() {
            if (finished) return
            finished = true
            handler.removeCallbacksAndMessages(null)
            try { player.release() } catch (_: Exception) {}
            onDone()
        }

        try {
            player.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION_SIGNALLING)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            player.setDataSource(file.absolutePath)
            player.setOnCompletionListener { finish() }
            player.setOnErrorListener { _, _, _ -> finish(); true }
            player.prepare()
            player.start()
            handler.postDelayed({ finish() }, 8000)
        } catch (e: Exception) {
            finish()
        }
    }
}

package com.tonelab.app.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

val ElectricViolet = Color(0xFF7C4DFF)
val ElectricBlue = Color(0xFF2979FF)

private val DarkColors = darkColorScheme(
    primary = ElectricViolet,
    onPrimary = Color.White,
    secondary = ElectricBlue,
    onSecondary = Color.White,
    tertiary = ElectricBlue,
    background = Color(0xFF0B0B14),
    onBackground = Color(0xFFEDEDF7),
    surface = Color(0xFF14141F),
    onSurface = Color(0xFFEDEDF7),
    surfaceVariant = Color(0xFF1E1E2E),
    onSurfaceVariant = Color(0xFFB5B5C9),
    primaryContainer = Color(0xFF2B1F66),
    onPrimaryContainer = Color(0xFFE3DBFF),
    error = Color(0xFFFF6B7A)
)

private val LightColors = lightColorScheme(
    primary = Color(0xFF5E35E0),
    onPrimary = Color.White,
    secondary = Color(0xFF1F5FE0),
    onSecondary = Color.White,
    tertiary = Color(0xFF1F5FE0),
    background = Color(0xFFF6F6FB),
    onBackground = Color(0xFF14141F),
    surface = Color.White,
    onSurface = Color(0xFF14141F),
    surfaceVariant = Color(0xFFE9E9F5),
    onSurfaceVariant = Color(0xFF4A4A5E),
    primaryContainer = Color(0xFFE3DBFF),
    onPrimaryContainer = Color(0xFF1B0F52)
)

private val AppShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(20.dp),
    large = RoundedCornerShape(28.dp)
)

@Composable
fun ToneLabTheme(darkTheme: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        shapes = AppShapes,
        content = content
    )
}

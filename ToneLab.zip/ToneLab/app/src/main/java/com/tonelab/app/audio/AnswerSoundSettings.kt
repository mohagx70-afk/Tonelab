package com.tonelab.app.audio

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.tonelab.app.data.AudioItem
import java.io.File

/**
 * Configuración del "sonido al coger la llamada". Se guarda en SharedPreferences para que
 * el receptor de llamadas pueda leerla aunque la app no esté abierta.
 */
class AnswerSoundSettings(context: Context) {

    private val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    var enabled by mutableStateOf(prefs.getBoolean(KEY_ENABLED, false))
        private set

    var itemId by mutableStateOf(prefs.getString(KEY_ID, null))
        private set

    fun select(item: AudioItem, file: File) {
        prefs.edit()
            .putString(KEY_ID, item.id)
            .putString(KEY_PATH, file.absolutePath)
            .putBoolean(KEY_ENABLED, true)
            .apply()
        itemId = item.id
        enabled = true
    }

    fun setEnabled(on: Boolean) {
        enabled = on
        prefs.edit().putBoolean(KEY_ENABLED, on).apply()
    }

    fun clear() {
        prefs.edit().remove(KEY_ID).remove(KEY_PATH).putBoolean(KEY_ENABLED, false).apply()
        itemId = null
        enabled = false
    }

    companion object {
        private const val PREFS = "answer_sound"
        private const val KEY_ENABLED = "enabled"
        private const val KEY_ID = "item_id"
        private const val KEY_PATH = "path"

        /** Archivo a reproducir al descolgar, o null si la función está apagada o el archivo ya no existe. */
        fun currentFile(context: Context): File? {
            val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            if (!p.getBoolean(KEY_ENABLED, false)) return null
            val path = p.getString(KEY_PATH, null) ?: return null
            val f = File(path)
            return if (f.exists()) f else null
        }
    }
}

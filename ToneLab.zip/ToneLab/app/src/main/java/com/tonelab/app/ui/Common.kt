package com.tonelab.app.ui

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.tonelab.app.AppViewModel
import com.tonelab.app.audio.ToneKind
import com.tonelab.app.audio.ToneResult
import com.tonelab.app.audio.ToneSetter
import com.tonelab.app.data.AudioItem
import kotlinx.coroutines.launch

/** m:ss */
fun formatDuration(ms: Long): String {
    val totalSeconds = ms / 1000
    return "%d:%02d".format(totalSeconds / 60, totalSeconds % 60)
}

/** m:ss.d */
fun formatPrecise(ms: Long): String {
    val totalSeconds = ms / 1000
    return "%d:%02d.%d".format(totalSeconds / 60, totalSeconds % 60, (ms % 1000) / 100)
}

fun formatBytes(bytes: Long): String = when {
    bytes < 1024 -> "$bytes B"
    bytes < 1024 * 1024 -> "%.1f KB".format(bytes / 1024.0)
    else -> "%.1f MB".format(bytes / (1024.0 * 1024.0))
}

/** Devuelve una función que abre el selector de archivos de audio y añade el resultado a la biblioteca. */
@Composable
fun rememberImporter(vm: AppViewModel): () -> Unit {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                val item = vm.repo.import(uri)
                val msg = if (item != null) "Importado: ${item.name}" else "No se pudo importar ese archivo"
                Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
            }
        }
    }
    return { launcher.launch(arrayOf("audio/*")) }
}

/** Diálogo para establecer un audio como tono de llamada, notificación o alarma. */
@Composable
fun SetToneDialog(item: AudioItem, vm: AppViewModel, onDismiss: () -> Unit) {
    val context = LocalContext.current
    var needsPermission by remember { mutableStateOf(false) }
    val requestPhone = rememberPhonePermissionRequester { granted ->
        val msg = if (granted) "Se usará al coger llamadas"
        else "Sin el permiso de teléfono no podrá detectar cuándo descuelgas"
        Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
        onDismiss()
    }

    if (needsPermission) {
        AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text("Permiso necesario") },
            text = {
                Text(
                    "Android pide un permiso especial para cambiar los sonidos del sistema. " +
                        "Se abrirá la pantalla de ajustes: activa \"Permitir modificar los ajustes del sistema\" " +
                        "y vuelve a ToneLab."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    context.startActivity(ToneSetter.permissionIntent(context))
                    onDismiss()
                }) { Text("Abrir ajustes") }
            },
            dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
        )
        return
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Establecer \"${item.name}\" como…") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                ToneKind.values().forEach { kind ->
                    FilledTonalButton(
                        onClick = {
                            when (val r = ToneSetter.apply(context, vm.repo.fileOf(item), item.name, kind)) {
                                is ToneResult.Success -> {
                                    Toast.makeText(context, "${kind.label} actualizado", Toast.LENGTH_SHORT).show()
                                    onDismiss()
                                }
                                is ToneResult.NeedsPermission -> needsPermission = true
                                is ToneResult.Failure -> Toast.makeText(
                                    context, "Error: ${r.message}", Toast.LENGTH_LONG
                                ).show()
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp)
                    ) { Text(kind.label) }
                }
                FilledTonalButton(
                    onClick = {
                        vm.answer.select(item, vm.repo.fileOf(item))
                        if (hasPhonePermission(context)) {
                            Toast.makeText(context, "Se usará al coger llamadas", Toast.LENGTH_SHORT).show()
                            onDismiss()
                        } else {
                            requestPhone()
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                ) { Text("Sonido al coger la llamada") }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

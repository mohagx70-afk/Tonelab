package com.tonelab.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.ContentCut
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.UploadFile
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.tonelab.app.AppViewModel
import com.tonelab.app.data.AudioItem
import com.tonelab.app.data.Kind

@Composable
fun LibraryScreen(vm: AppViewModel, onEdit: (String) -> Unit) {
    val items by vm.repo.items.collectAsState()
    val importAudio = rememberImporter(vm)
    var filter by remember { mutableStateOf<Kind?>(null) }
    var renaming by remember { mutableStateOf<AudioItem?>(null) }
    var deleting by remember { mutableStateOf<AudioItem?>(null) }
    var setting by remember { mutableStateOf<AudioItem?>(null) }

    val shown = items.filter { filter == null || it.kind == filter }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Biblioteca",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
            Button(onClick = importAudio) {
                Icon(Icons.Rounded.UploadFile, contentDescription = null)
                Text("  Importar")
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = filter == null, onClick = { filter = null }, label = { Text("Todo") })
            FilterChip(
                selected = filter == Kind.IMPORTED,
                onClick = { filter = Kind.IMPORTED },
                label = { Text("Audios") }
            )
            FilterChip(
                selected = filter == Kind.TONE,
                onClick = { filter = Kind.TONE },
                label = { Text("Tonos") }
            )
        }

        if (shown.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    "Todavía no hay nada aquí.\nImporta un audio para empezar.",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(shown, key = { it.id }) { item ->
                    ItemRow(
                        item = item,
                        playing = vm.player.playingKey == item.id,
                        onPlay = {
                            if (vm.player.playingKey == item.id) vm.player.stop()
                            else vm.player.play(item.id, vm.repo.fileOf(item))
                        },
                        onEdit = { onEdit(item.id) },
                        onRename = { renaming = item },
                        onSetTone = { setting = item },
                        onDelete = { deleting = item }
                    )
                }
            }
        }
    }

    renaming?.let { item ->
        var text by remember(item.id) { mutableStateOf(item.name) }
        AlertDialog(
            onDismissRequest = { renaming = null },
            title = { Text("Renombrar") },
            text = {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                TextButton(
                    enabled = text.isNotBlank(),
                    onClick = {
                        vm.repo.rename(item.id, text.trim())
                        renaming = null
                    }
                ) { Text("Guardar") }
            },
            dismissButton = { TextButton(onClick = { renaming = null }) { Text("Cancelar") } }
        )
    }

    deleting?.let { item ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("Eliminar") },
            text = { Text("¿Eliminar \"${item.name}\" de la biblioteca? Esta acción no se puede deshacer.") },
            confirmButton = {
                TextButton(onClick = {
                    if (vm.player.playingKey == item.id) vm.player.stop()
                    if (vm.editorItemId == item.id) vm.editorItemId = null
                    if (vm.answer.itemId == item.id) vm.answer.clear()
                    vm.repo.delete(item.id)
                    deleting = null
                }) { Text("Eliminar", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Cancelar") } }
        )
    }

    setting?.let { item ->
        SetToneDialog(item = item, vm = vm, onDismiss = { setting = null })
    }
}

@Composable
private fun ItemRow(
    item: AudioItem,
    playing: Boolean,
    onPlay: () -> Unit,
    onEdit: () -> Unit,
    onRename: () -> Unit,
    onSetTone: () -> Unit,
    onDelete: () -> Unit
) {
    var menuOpen by remember { mutableStateOf(false) }
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            FilledIconButton(onClick = onPlay, modifier = Modifier.size(52.dp)) {
                Icon(
                    if (playing) Icons.Rounded.Stop else Icons.Rounded.PlayArrow,
                    contentDescription = if (playing) "Parar" else "Reproducir"
                )
            }
            Column(Modifier.weight(1f)) {
                Text(
                    item.name,
                    style = MaterialTheme.typography.titleMedium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    (if (item.kind == Kind.TONE) "Tono" else "Audio") + " · " + formatDuration(item.durationMs),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Box {
                IconButton(onClick = { menuOpen = true }) {
                    Icon(Icons.Rounded.MoreVert, contentDescription = "Más opciones")
                }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    DropdownMenuItem(
                        text = { Text("Establecer como tono") },
                        leadingIcon = { Icon(Icons.Rounded.MusicNote, null) },
                        onClick = { menuOpen = false; onSetTone() }
                    )
                    DropdownMenuItem(
                        text = { Text("Editar") },
                        leadingIcon = { Icon(Icons.Rounded.ContentCut, null) },
                        onClick = { menuOpen = false; onEdit() }
                    )
                    DropdownMenuItem(
                        text = { Text("Renombrar") },
                        leadingIcon = { Icon(Icons.Rounded.Edit, null) },
                        onClick = { menuOpen = false; onRename() }
                    )
                    DropdownMenuItem(
                        text = { Text("Eliminar") },
                        leadingIcon = { Icon(Icons.Rounded.Delete, null) },
                        onClick = { menuOpen = false; onDelete() }
                    )
                }
            }
        }
    }
}

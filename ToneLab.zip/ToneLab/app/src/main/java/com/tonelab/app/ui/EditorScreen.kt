package com.tonelab.app.ui

import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Spacer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ContentCopy
import androidx.compose.material.icons.rounded.ContentCut
import androidx.compose.material.icons.rounded.ContentPaste
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material.icons.rounded.TrendingDown
import androidx.compose.material.icons.rounded.TrendingUp
import androidx.compose.material.icons.rounded.Undo
import androidx.compose.material.icons.rounded.VolumeDown
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.tonelab.app.AppViewModel
import com.tonelab.app.audio.AudioProcessing
import com.tonelab.app.audio.Pcm
import com.tonelab.app.data.AudioItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.max
import kotlin.math.min

/** Resultado de una edición: el audio nuevo y qué parte queda seleccionada (selEndMs < 0 = todo). */
private class Edit(val pcm: Pcm, val selStartMs: Long = 0, val selEndMs: Long = -1)

@Composable
fun EditorScreen(vm: AppViewModel) {
    val items by vm.repo.items.collectAsState()
    val item = items.firstOrNull { it.id == vm.editorItemId }
    if (item == null) {
        EditorPicker(vm)
    } else {
        EditorContent(vm, item)
    }
}

@Composable
private fun EditorPicker(vm: AppViewModel) {
    val items by vm.repo.items.collectAsState()
    val importAudio = rememberImporter(vm)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            "Editor",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(top = 12.dp)
        )
        Text(
            "Elige el audio que quieres editar.",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        if (items.isEmpty()) {
            Button(
                onClick = importAudio,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
            ) { Text("Importar un audio") }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(items, key = { it.id }) { audio ->
                    Card(
                        onClick = { vm.editorItemId = audio.id },
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Icon(Icons.Rounded.MusicNote, contentDescription = null)
                            Text(
                                audio.name,
                                style = MaterialTheme.typography.titleMedium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                            Text(formatDuration(audio.durationMs))
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
private fun EditorContent(vm: AppViewModel, item: AudioItem) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var pcm by remember(item.id) { mutableStateOf<Pcm?>(null) }
    var peaks by remember(item.id) { mutableStateOf<FloatArray?>(null) }
    var error by remember(item.id) { mutableStateOf<String?>(null) }
    var range by remember(item.id) { mutableStateOf(0f..1f) }
    var name by remember(item.id) { mutableStateOf("${item.name} (tono)") }
    var busy by remember(item.id) { mutableStateOf(false) }
    var saving by remember(item.id) { mutableStateOf(false) }
    var savedItem by remember(item.id) { mutableStateOf<AudioItem?>(null) }
    var showSetTone by remember { mutableStateOf(false) }
    val history = remember(item.id) { mutableStateListOf<Pcm>() }

    val file = vm.repo.fileOf(item)

    LaunchedEffect(item.id) {
        val result = withContext(Dispatchers.Default) {
            runCatching {
                val p = AudioProcessing.decode(file)
                p to AudioProcessing.waveform(p, 160)
            }
        }
        result.onSuccess { (p, w) ->
            pcm = p
            peaks = w
            // Por defecto, como mucho los primeros 30 s
            val end = if (p.durationMs > 30_000) 30_000f / p.durationMs else 1f
            range = 0f..min(1f, end)
        }.onFailure { error = "No se pudo leer este audio" }
    }

    DisposableEffect(item.id) {
        onDispose { vm.player.stop() }
    }

    /** Aplica una edición en segundo plano, guarda el estado anterior para poder deshacer y actualiza la onda. */
    fun runEdit(op: (Pcm) -> Edit) {
        val current = pcm ?: return
        if (busy) return
        vm.player.stop()
        busy = true
        scope.launch {
            val result = withContext(Dispatchers.Default) {
                runCatching {
                    val e = op(current)
                    e to AudioProcessing.waveform(e.pcm, 160)
                }
            }
            result.onSuccess { (e, w) ->
                history.add(current)
                if (history.size > 6) history.removeAt(0)
                pcm = e.pcm
                peaks = w
                val total = max(1L, e.pcm.durationMs).toFloat()
                range = if (e.selEndMs < 0) {
                    0f..1f
                } else {
                    val a = (e.selStartMs / total).coerceIn(0f, 1f)
                    val b = (e.selEndMs / total).coerceIn(a, 1f)
                    a..b
                }
            }.onFailure {
                Toast.makeText(context, "No se pudo aplicar el cambio", Toast.LENGTH_LONG).show()
            }
            busy = false
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    "Editor",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    item.name,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            OutlinedButton(onClick = {
                vm.player.stop()
                vm.editorItemId = null
            }) { Text("Cambiar") }
        }

        val p = pcm
        val w = peaks
        when {
            error != null -> Text(error!!, color = MaterialTheme.colorScheme.error)
            p == null || w == null -> Box(
                Modifier
                    .fillMaxWidth()
                    .height(160.dp),
                contentAlignment = Alignment.Center
            ) { CircularProgressIndicator() }
            else -> {
                val total = p.durationMs
                val startMs = (range.start * total).toLong()
                val endMs = (range.endInclusive * total).toLong()
                val previewing = vm.player.playingKey == "preview"
                val playhead = if (previewing && total > 0) vm.player.positionMs / total.toFloat() else null
                val clip = vm.clipboard

                Waveform(peaks = w, start = range.start, end = range.endInclusive, playhead = playhead)

                RangeSlider(
                    value = range,
                    onValueChange = { r ->
                        if (vm.player.playingKey == "preview") vm.player.stop()
                        range = r
                    },
                    valueRange = 0f..1f
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Inicio ${formatPrecise(startMs)}")
                    Text("Selección ${formatPrecise(max(0L, endMs - startMs))}", fontWeight = FontWeight.SemiBold)
                    Text("Fin ${formatPrecise(endMs)}")
                }
                Text(
                    "Duración total: ${formatPrecise(total)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Button(
                    onClick = {
                        if (previewing) {
                            vm.player.stop()
                        } else {
                            vm.player.stop()
                            scope.launch {
                                val tmp = File(context.cacheDir, "preview.wav")
                                withContext(Dispatchers.IO) {
                                    AudioProcessing.writeWav(p, 0, p.durationMs, tmp)
                                }
                                vm.player.play("preview", tmp, startMs, endMs)
                            }
                        }
                    },
                    enabled = !busy,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                ) {
                    Icon(if (previewing) Icons.Rounded.Stop else Icons.Rounded.PlayArrow, null)
                    Text(if (previewing) "  Parar" else "  Escuchar selección")
                }

                // ---------- Herramientas ----------
                SectionTitle("Herramientas (actúan sobre la selección)")
                if (busy) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        CircularProgressIndicator(modifier = Modifier.height(20.dp).width(20.dp), strokeWidth = 2.dp)
                        Text("Aplicando…")
                    }
                }
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ToolButton(Icons.Rounded.ContentCut, "Recortar", !busy) {
                        runEdit { Edit(AudioProcessing.slice(it, startMs, endMs)) }
                    }
                    ToolButton(Icons.Rounded.Delete, "Eliminar", !busy) {
                        runEdit { Edit(AudioProcessing.delete(it, startMs, endMs)) }
                    }
                    ToolButton(Icons.Rounded.ContentCopy, "Copiar", !busy) {
                        if (endMs - startMs < 50) {
                            Toast.makeText(context, "Selecciona un tramo para copiar", Toast.LENGTH_SHORT).show()
                        } else {
                            vm.clipboard = AudioProcessing.slice(p, startMs, endMs)
                            Toast.makeText(context, "Copiado", Toast.LENGTH_SHORT).show()
                        }
                    }
                    ToolButton(Icons.Rounded.ContentPaste, "Pegar", !busy && clip != null) {
                        val c = clip ?: return@ToolButton
                        runEdit { Edit(AudioProcessing.insert(it, startMs, c), startMs, startMs + c.durationMs) }
                    }
                    ToolButton(Icons.Rounded.Repeat, "Repetir", !busy) {
                        runEdit {
                            val part = AudioProcessing.slice(it, startMs, endMs)
                            Edit(AudioProcessing.insert(it, endMs, part), endMs, endMs + (endMs - startMs))
                        }
                    }
                    ToolButton(Icons.Rounded.SwapHoriz, "Al revés", !busy) {
                        runEdit { Edit(AudioProcessing.reverse(it, startMs, endMs), startMs, endMs) }
                    }
                    ToolButton(Icons.Rounded.TrendingUp, "Fundido entrada", !busy) {
                        runEdit { Edit(AudioProcessing.fade(it, startMs, endMs, true), startMs, endMs) }
                    }
                    ToolButton(Icons.Rounded.TrendingDown, "Fundido salida", !busy) {
                        runEdit { Edit(AudioProcessing.fade(it, startMs, endMs, false), startMs, endMs) }
                    }
                    ToolButton(Icons.Rounded.VolumeUp, "Más volumen", !busy) {
                        runEdit { Edit(AudioProcessing.gain(it, startMs, endMs, 1.25f), startMs, endMs) }
                    }
                    ToolButton(Icons.Rounded.VolumeDown, "Menos volumen", !busy) {
                        runEdit { Edit(AudioProcessing.gain(it, startMs, endMs, 0.8f), startMs, endMs) }
                    }
                    ToolButton(Icons.Rounded.Undo, "Deshacer", !busy && history.isNotEmpty()) {
                        vm.player.stop()
                        val previous = history.removeAt(history.lastIndex)
                        pcm = previous
                        range = 0f..1f
                        scope.launch {
                            peaks = withContext(Dispatchers.Default) {
                                AudioProcessing.waveform(previous, 160)
                            }
                        }
                    }
                }
                Text(
                    if (clip != null) "Portapapeles: ${formatPrecise(clip.durationMs)} (se pega al inicio de la selección)"
                    else "Portapapeles vacío. Selecciona un tramo y pulsa Copiar.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                SectionTitle("Cambiar el tono (grave / agudo)")
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf(-4, -2, -1, 1, 2, 4).forEach { st ->
                        FilledTonalButton(
                            enabled = !busy,
                            onClick = {
                                val factor = Math.pow(2.0, st / 12.0)
                                runEdit {
                                    Edit(
                                        AudioProcessing.changePitch(it, startMs, endMs, st),
                                        startMs,
                                        startMs + ((endMs - startMs) / factor).toLong()
                                    )
                                }
                            },
                            modifier = Modifier.height(48.dp)
                        ) { Text(if (st > 0) "+$st" else "$st") }
                    }
                }
                Text(
                    "Cada número es un semitono. Al cambiar el tono también cambia la velocidad: " +
                        "más agudo suena más rápido y más corto.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                // ---------- Guardar ----------
                SectionTitle("Guardar")
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Nombre del tono") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    "Se guardará la parte seleccionada (${formatPrecise(max(0L, endMs - startMs))}). " +
                        "El audio original no se modifica.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Button(
                    enabled = !saving && !busy && name.isNotBlank(),
                    onClick = {
                        if (endMs - startMs < 500) {
                            Toast.makeText(context, "El fragmento es demasiado corto", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        vm.player.stop()
                        saving = true
                        scope.launch {
                            val created = withContext(Dispatchers.IO) {
                                runCatching {
                                    val out = vm.repo.newFile("wav")
                                    val dur = AudioProcessing.writeWav(p, startMs, endMs, out)
                                    vm.repo.addTone(out, name.trim(), dur)
                                }
                            }
                            saving = false
                            created.onSuccess {
                                savedItem = it
                                Toast.makeText(context, "Tono guardado en la biblioteca", Toast.LENGTH_SHORT).show()
                            }.onFailure {
                                Toast.makeText(context, "No se pudo guardar el tono", Toast.LENGTH_LONG).show()
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                ) {
                    Icon(Icons.Rounded.Save, null)
                    Text(if (saving) "  Guardando…" else "  Guardar como nuevo tono")
                }

                savedItem?.let {
                    OutlinedButton(
                        onClick = { showSetTone = true },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp)
                    ) { Text("Establecer \"${it.name}\" como tono") }
                }
            }
        }
    }

    val toSet = savedItem
    if (showSetTone && toSet != null) {
        SetToneDialog(item = toSet, vm = vm, onDismiss = { showSetTone = false })
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(top = 8.dp)
    )
}

@Composable
private fun ToolButton(icon: ImageVector, label: String, enabled: Boolean, onClick: () -> Unit) {
    FilledTonalButton(
        onClick = onClick,
        enabled = enabled,
        modifier = Modifier.height(48.dp)
    ) {
        Icon(icon, contentDescription = null)
        Spacer(Modifier.width(6.dp))
        Text(label)
    }
}

@Composable
private fun Waveform(peaks: FloatArray, start: Float, end: Float, playhead: Float?) {
    val active = MaterialTheme.colorScheme.primary
    val dim = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.35f)
    val head = MaterialTheme.colorScheme.secondary
    Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .height(160.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
    ) {
        val n = peaks.size
        val barWidth = size.width / n
        peaks.forEachIndexed { i, peak ->
            val frac = i / n.toFloat()
            val selected = frac >= start && frac <= end
            val h = max(6f, peak * size.height * 0.85f)
            val x = i * barWidth + barWidth / 2
            drawLine(
                color = if (selected) active else dim,
                start = Offset(x, (size.height - h) / 2),
                end = Offset(x, (size.height + h) / 2),
                strokeWidth = barWidth * 0.6f,
                cap = StrokeCap.Round
            )
        }
        if (playhead != null) {
            val x = playhead.coerceIn(0f, 1f) * size.width
            drawLine(head, Offset(x, 0f), Offset(x, size.height), strokeWidth = 4f)
        }
    }
}

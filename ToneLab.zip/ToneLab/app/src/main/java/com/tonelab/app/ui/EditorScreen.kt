package com.tonelab.app.ui

import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.tonelab.app.AppViewModel
import com.tonelab.app.audio.AudioProcessing
import com.tonelab.app.audio.Pcm
import com.tonelab.app.data.AudioItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.min

@Composable
fun EditorScreen(vm: AppViewModel) {
    val items by vm.repo.items.collectAsState()
    val item = items.firstOrNull { it.id == vm.editorItemId }
    if (item == null) {
        EditorPicker(vm)
    } else {
        EditorContent(vm, item)
    }
}

@Composable
private fun EditorPicker(vm: AppViewModel) {
    val items by vm.repo.items.collectAsState()
    val importAudio = rememberImporter(vm)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            "Editor",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(top = 12.dp)
        )
        Text(
            "Elige el audio que quieres recortar.",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        if (items.isEmpty()) {
            Button(
                onClick = importAudio,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
            ) { Text("Importar un audio") }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(items, key = { it.id }) { audio ->
                    Card(
                        onClick = { vm.editorItemId = audio.id },
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Icon(Icons.Rounded.MusicNote, contentDescription = null)
                            Text(
                                audio.name,
                                style = MaterialTheme.typography.titleMedium,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                            Text(formatDuration(audio.durationMs))
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EditorContent(vm: AppViewModel, item: AudioItem) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var pcm by remember(item.id) { mutableStateOf<Pcm?>(null) }
    var peaks by remember(item.id) { mutableStateOf<FloatArray?>(null) }
    var error by remember(item.id) { mutableStateOf<String?>(null) }
    var range by remember(item.id) { mutableStateOf(0f..1f) }
    var name by remember(item.id) { mutableStateOf("${item.name} (tono)") }
    var saving by remember(item.id) { mutableStateOf(false) }
    var savedItem by remember(item.id) { mutableStateOf<AudioItem?>(null) }
    var showSetTone by remember { mutableStateOf(false) }

    val file = vm.repo.fileOf(item)

    LaunchedEffect(item.id) {
        val result = withContext(Dispatchers.Default) {
            runCatching {
                val p = AudioProcessing.decode(file)
                p to AudioProcessing.waveform(p, 160)
            }
        }
        result.onSuccess { (p, w) ->
            pcm = p
            peaks = w
            // Por defecto, como mucho los primeros 30 s
            val end = if (p.durationMs > 30_000) 30_000f / p.durationMs else 1f
            range = 0f..min(1f, end)
        }.onFailure { error = "No se pudo leer este audio" }
    }

    DisposableEffect(item.id) {
        onDispose { vm.player.stop() }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    "Editor",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    item.name,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
            OutlinedButton(onClick = {
                vm.player.stop()
                vm.editorItemId = null
            }) { Text("Cambiar") }
        }

        val p = pcm
        val w = peaks
        when {
            error != null -> Text(error!!, color = MaterialTheme.colorScheme.error)
            p == null || w == null -> Box(
                Modifier
                    .fillMaxWidth()
                    .height(160.dp),
                contentAlignment = Alignment.Center
            ) { CircularProgressIndicator() }
            else -> {
                val total = p.durationMs
                val startMs = (range.start * total).toLong()
                val endMs = (range.endInclusive * total).toLong()
                val previewing = vm.player.playingKey == "preview"
                val playhead = if (previewing && total > 0) vm.player.positionMs / total.toFloat() else null

                Waveform(peaks = w, start = range.start, end = range.endInclusive, playhead = playhead)

                RangeSlider(
                    value = range,
                    onValueChange = { r ->
                        if (vm.player.playingKey == "preview") vm.player.stop()
                        range = r
                    },
                    valueRange = 0f..1f
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Inicio ${formatPrecise(startMs)}")
                    Text("Duración ${formatPrecise(max(0L, endMs - startMs))}", fontWeight = FontWeight.SemiBold)
                    Text("Fin ${formatPrecise(endMs)}")
                }

                Button(
                    onClick = {
                        if (previewing) vm.player.stop()
                        else vm.player.play("preview", file, startMs, endMs)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                ) {
                    Icon(if (previewing) Icons.Rounded.Stop else Icons.Rounded.PlayArrow, null)
                    Text(if (previewing) "  Parar" else "  Previsualizar fragmento")
                }

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Nombre del tono") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Button(
                    enabled = !saving && name.isNotBlank(),
                    onClick = {
                        if (endMs - startMs < 500) {
                            Toast.makeText(context, "El fragmento es demasiado corto", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        vm.player.stop()
                        saving = true
                        scope.launch {
                            val created = withContext(Dispatchers.IO) {
                                runCatching {
                                    val out = vm.repo.newFile("wav")
                                    val dur = AudioProcessing.writeWav(p, startMs, endMs, out)
                                    vm.repo.addTone(out, name.trim(), dur)
                                }
                            }
                            saving = false
                            created.onSuccess {
                                savedItem = it
                                Toast.makeText(context, "Tono guardado en la biblioteca", Toast.LENGTH_SHORT).show()
                            }.onFailure {
                                Toast.makeText(context, "No se pudo guardar el tono", Toast.LENGTH_LONG).show()
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp)
                ) {
                    Icon(Icons.Rounded.Save, null)
                    Text(if (saving) "  Guardando…" else "  Guardar como nuevo tono")
                }

                savedItem?.let {
                    OutlinedButton(
                        onClick = { showSetTone = true },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp)
                    ) { Text("Establecer \"${it.name}\" como tono") }
                }
            }
        }
    }

    val toSet = savedItem
    if (showSetTone && toSet != null) {
        SetToneDialog(item = toSet, vm = vm, onDismiss = { showSetTone = false })
    }
}

@Composable
private fun Waveform(peaks: FloatArray, start: Float, end: Float, playhead: Float?) {
    val active = MaterialTheme.colorScheme.primary
    val dim = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.35f)
    val head = MaterialTheme.colorScheme.secondary
    Canvas(
        modifier = Modifier
            .fillMaxWidth()
            .height(160.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
    ) {
        val n = peaks.size
        val barWidth = size.width / n
        peaks.forEachIndexed { i, peak ->
            val frac = i / n.toFloat()
            val selected = frac >= start && frac <= end
            val h = max(6f, peak * size.height * 0.85f)
            val x = i * barWidth + barWidth / 2
            drawLine(
                color = if (selected) active else dim,
                start = Offset(x, (size.height - h) / 2),
                end = Offset(x, (size.height + h) / 2),
                strokeWidth = barWidth * 0.6f,
                cap = StrokeCap.Round
            )
        }
        if (playhead != null) {
            val x = playhead.coerceIn(0f, 1f) * size.width
            drawLine(head, Offset(x, 0f), Offset(x, size.height), strokeWidth = 4f)
        }
    }
}

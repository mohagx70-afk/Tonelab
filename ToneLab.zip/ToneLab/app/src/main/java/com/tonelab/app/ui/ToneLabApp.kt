package com.tonelab.app.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ContentCut
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.LibraryMusic
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.tonelab.app.AppViewModel

private enum class Tab(val route: String, val label: String, val icon: ImageVector) {
    Home("home", "Inicio", Icons.Rounded.Home),
    Library("library", "Biblioteca", Icons.Rounded.LibraryMusic),
    Editor("editor", "Editor", Icons.Rounded.ContentCut),
    Settings("settings", "Ajustes", Icons.Rounded.Settings)
}

@Composable
fun ToneLabApp(vm: AppViewModel) {
    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val currentRoute = backStack?.destination?.route

    fun go(route: String) {
        vm.player.stop()
        nav.navigate(route) {
            popUpTo(nav.graph.findStartDestination().id) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    Scaffold(
        bottomBar = {
            NavigationBar {
                Tab.values().forEach { tab ->
                    NavigationBarItem(
                        selected = currentRoute == tab.route,
                        onClick = { go(tab.route) },
                        icon = { Icon(tab.icon, contentDescription = tab.label) },
                        label = { Text(tab.label) }
                    )
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = nav,
            startDestination = Tab.Home.route,
            modifier = Modifier.padding(padding)
        ) {
            composable(Tab.Home.route) {
                HomeScreen(
                    vm = vm,
                    onOpenEditor = { go(Tab.Editor.route) },
                    onOpenLibrary = { go(Tab.Library.route) }
                )
            }
            composable(Tab.Library.route) {
                LibraryScreen(
                    vm = vm,
                    onEdit = { id ->
                        vm.editorItemId = id
                        go(Tab.Editor.route)
                    }
                )
            }
            composable(Tab.Editor.route) { EditorScreen(vm) }
            composable(Tab.Settings.route) { SettingsScreen(vm) }
        }
    }
}

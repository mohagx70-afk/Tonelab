package com.tonelab.app.audio

import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class Pcm(val samples: ShortArray, val sampleRate: Int, val channels: Int) {
    val frames: Int get() = if (channels == 0) 0 else samples.size / channels
    val durationMs: Long get() = if (sampleRate == 0) 0 else frames * 1000L / sampleRate
}

object AudioProcessing {

    /** Decodifica cualquier audio soportado por Android a PCM de 16 bits. */
    fun decode(file: File): Pcm {
        val extractor = MediaExtractor()
        extractor.setDataSource(file.absolutePath)
        var trackIndex = -1
        var format: MediaFormat? = null
        for (i in 0 until extractor.trackCount) {
            val f = extractor.getTrackFormat(i)
            if (f.getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true) {
                trackIndex = i
                format = f
                break
            }
        }
        if (trackIndex < 0 || format == null) {
            extractor.release()
            throw IllegalArgumentException("El archivo no contiene audio")
        }
        extractor.selectTrack(trackIndex)

        val mime = format.getString(MediaFormat.KEY_MIME)!!
        val codec = MediaCodec.createDecoderByType(mime)
        codec.configure(format, null, null, 0)
        codec.start()

        var sampleRate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        var channels = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
        var out = ShortArray(sampleRate * channels * 30)
        var size = 0

        val info = MediaCodec.BufferInfo()
        var inputDone = false
        var outputDone = false
        try {
            while (!outputDone) {
                if (!inputDone) {
                    val idx = codec.dequeueInputBuffer(10_000)
                    if (idx >= 0) {
                        val buf = codec.getInputBuffer(idx)!!
                        val n = extractor.readSampleData(buf, 0)
                        if (n < 0) {
                            codec.queueInputBuffer(
                                idx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM
                            )
                            inputDone = true
                        } else {
                            codec.queueInputBuffer(idx, 0, n, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }
                val o = codec.dequeueOutputBuffer(info, 10_000)
                when {
                    o >= 0 -> {
                        val buf = codec.getOutputBuffer(o)!!
                        buf.position(info.offset)
                        buf.limit(info.offset + info.size)
                        val sb = buf.order(ByteOrder.nativeOrder()).asShortBuffer()
                        val n = sb.remaining()
                        if (size + n > out.size) {
                            out = out.copyOf(max(out.size * 2, size + n))
                        }
                        sb.get(out, size, n)
                        size += n
                        codec.releaseOutputBuffer(o, false)
                        if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                            outputDone = true
                        }
                    }
                    o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val nf = codec.outputFormat
                        sampleRate = nf.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        channels = nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    }
                }
            }
        } finally {
            try { codec.stop() } catch (_: Exception) {}
            codec.release()
            extractor.release()
        }
        return Pcm(out.copyOf(size - size % channels), sampleRate, channels)
    }

    /** Devuelve [bars] picos normalizados (0..1) para dibujar la onda. */
    fun waveform(pcm: Pcm, bars: Int): FloatArray {
        val frames = pcm.frames
        val peaks = FloatArray(bars)
        if (frames == 0) return peaks
        for (b in 0 until bars) {
            val s = (b.toLong() * frames / bars).toInt()
            val e = min(frames, ((b + 1).toLong() * frames / bars).toInt())
            val step = max(1, (e - s) / 64)
            var m = 0
            var f = s
            while (f < e) {
                for (c in 0 until pcm.channels) {
                    m = max(m, abs(pcm.samples[f * pcm.channels + c].toInt()))
                }
                f += step
            }
            peaks[b] = m / 32768f
        }
        val top = peaks.maxOrNull() ?: 0f
        if (top > 0f) for (i in peaks.indices) peaks[i] = peaks[i] / top
        return peaks
    }

    /** Escribe el fragmento [startMs, endMs] como WAV de 16 bits. El original no se toca. */
    fun writeWav(pcm: Pcm, startMs: Long, endMs: Long, out: File): Long {
        val startFrame = (startMs * pcm.sampleRate / 1000).toInt().coerceIn(0, pcm.frames)
        val endFrame = (endMs * pcm.sampleRate / 1000).toInt().coerceIn(startFrame, pcm.frames)
        val frameCount = endFrame - startFrame
        val sampleCount = frameCount * pcm.channels
        val dataBytes = sampleCount * 2
        val fade = min(frameCount / 2, pcm.sampleRate / 100) // 10 ms para evitar clics

        RandomAccessFile(out, "rw").use { raf ->
            raf.setLength(0)
            val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
            header.put("RIFF".toByteArray())
            header.putInt(36 + dataBytes)
            header.put("WAVE".toByteArray())
            header.put("fmt ".toByteArray())
            header.putInt(16)
            header.putShort(1)
            header.putShort(pcm.channels.toShort())
            header.putInt(pcm.sampleRate)
            header.putInt(pcm.sampleRate * pcm.channels * 2)
            header.putShort((pcm.channels * 2).toShort())
            header.putShort(16)
            header.put("data".toByteArray())
            header.putInt(dataBytes)
            raf.write(header.array())

            val chunkFrames = 8192
            val buf = ByteBuffer.allocate(chunkFrames * pcm.channels * 2)
                .order(ByteOrder.LITTLE_ENDIAN)
            var f = 0
            while (f < frameCount) {
                buf.clear()
                val n = min(chunkFrames, frameCount - f)
                for (i in 0 until n) {
                    val frame = f + i
                    var gain = 1f
                    if (frame < fade) gain = frame / fade.toFloat()
                    else if (frame >= frameCount - fade) gain = (frameCount - frame) / fade.toFloat()
                    for (c in 0 until pcm.channels) {
                        val v = pcm.samples[(startFrame + frame) * pcm.channels + c]
                        buf.putShort((v * gain).toInt().toShort())
                    }
                }
                raf.write(buf.array(), 0, n * pcm.channels * 2)
                f += n
            }
        }
        return frameCount * 1000L / pcm.sampleRate
    }
}

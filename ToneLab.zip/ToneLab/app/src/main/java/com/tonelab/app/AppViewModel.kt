package com.tonelab.app

import android.app.Application
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import com.tonelab.app.audio.AnswerSoundSettings
import com.tonelab.app.audio.AudioPlayer
import com.tonelab.app.audio.Pcm
import com.tonelab.app.data.LibraryRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/** Estado compartido por las cuatro secciones de la app. */
class AppViewModel(app: Application) : AndroidViewModel(app) {

    val repo = LibraryRepository(app)
    val player = AudioPlayer()
    val answer = AnswerSoundSettings(app)

    private val prefs = app.getSharedPreferences("settings", Context.MODE_PRIVATE)
    private val _darkTheme = MutableStateFlow(prefs.getBoolean("dark", true))
    val darkTheme: StateFlow<Boolean> = _darkTheme

    /** Fragmento copiado en el editor; sirve para pegarlo también en otro audio. */
    var clipboard by mutableStateOf<Pcm?>(null)

    /** Audio seleccionado en el editor (null = ninguno). */
    var editorItemId by mutableStateOf<String?>(null)

    fun setDarkTheme(dark: Boolean) {
        _darkTheme.value = dark
        prefs.edit().putBoolean("dark", dark).apply()
    }

    override fun onCleared() {
        player.release()
    }
}

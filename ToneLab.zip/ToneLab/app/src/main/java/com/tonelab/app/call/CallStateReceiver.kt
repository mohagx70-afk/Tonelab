package com.tonelab.app.call

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.TelephonyManager
import com.tonelab.app.audio.AnswerSoundPlayer
import com.tonelab.app.audio.AnswerSoundSettings

/**
 * Escucha los cambios de estado del teléfono. Cuando una llamada pasa de "sonando" a
 * "en curso" (has descolgado), reproduce el sonido elegido.
 */
class CallStateReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != TelephonyManager.ACTION_PHONE_STATE_CHANGED) return
        val state = intent.getStringExtra(TelephonyManager.EXTRA_STATE) ?: return

        val prefs = context.getSharedPreferences("call_state", Context.MODE_PRIVATE)
        val last = prefs.getString("last", TelephonyManager.EXTRA_STATE_IDLE)
        if (state == last) return // Android a veces envía el mismo aviso dos veces
        prefs.edit().putString("last", state).apply()

        val answered = state == TelephonyManager.EXTRA_STATE_OFFHOOK &&
            last == TelephonyManager.EXTRA_STATE_RINGING
        if (!answered) return

        val file = AnswerSoundSettings.currentFile(context) ?: return
        val pending = goAsync()
        AnswerSoundPlayer.play(file) { pending.finish() }
    }
}

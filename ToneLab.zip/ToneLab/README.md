# ToneLab

Aplicación Android (Kotlin + Jetpack Compose) para importar audios, recortarlos y usarlos como tono de llamada, notificación o alarma. Sin servidores, cuentas ni conexión a Internet.

## Cómo compilar la APK

1. Abre la carpeta `ToneLab` en **Android Studio** (Koala o superior).
2. Espera a que Gradle sincronice (Android Studio descargará el SDK y las dependencias; instala un JDK 17 si lo pide).
3. Conecta un móvil con depuración USB o abre un emulador (Android 10 / API 29 o superior).
4. Pulsa **Run ▶** para instalarla, o **Build > Build APK(s)** para generar la APK en `app/build/outputs/apk/debug/`.

Desde terminal (con Gradle wrapper generado por Android Studio): `./gradlew assembleDebug`.

## Flujo básico

1. **Inicio > Importar audio** y elige un archivo del móvil.
2. **Biblioteca > ⋮ > Editar** (o pestaña **Editor**).
3. Mueve los dos extremos del selector, usa **Previsualizar fragmento** y pulsa **Guardar como nuevo tono**.
4. **Establecer como tono**: la primera vez Android pedirá el permiso "Modificar los ajustes del sistema".

## Estructura

```
app/src/main/java/com/tonelab/app/
├── MainActivity.kt          Punto de entrada
├── AppViewModel.kt          Estado compartido (tema, editor, biblioteca, reproductor)
├── data/
│   ├── AudioItem.kt         Modelo de un audio importado o tono creado
│   └── LibraryRepository.kt Biblioteca local (archivos + library.json)
├── audio/
│   ├── AudioProcessing.kt   Decodificación, onda sonora y recorte a WAV
│   ├── AudioPlayer.kt       Reproducción y previsualización de tramos
│   └── ToneSetter.kt        Publicación en MediaStore y ajuste de tonos del sistema
└── ui/
    ├── ToneLabApp.kt        Navegación inferior (Inicio, Biblioteca, Editor, Ajustes)
    ├── HomeScreen.kt  LibraryScreen.kt  EditorScreen.kt  SettingsScreen.kt
    ├── Common.kt            Importador, diálogo "Establecer como…", formatos
    └── theme/Theme.kt       Tema oscuro/claro con violeta y azul eléctrico
```

## Decisiones técnicas

- **Recorte sin modificar el original**: el fragmento se decodifica a PCM y se guarda como un `.wav` nuevo (con un fundido de 10 ms para evitar clics). Los WAV ocupan más que un MP3, pero para tonos cortos es irrelevante y evita depender de codificadores.
- **Sin permisos de almacenamiento**: los archivos se eligen con el selector del sistema (SAF) y los tonos se publican con MediaStore. El único permiso especial es `WRITE_SETTINGS`.
- **Preparada para crecer**: toda la persistencia está detrás de `LibraryRepository`; para añadir una biblioteca comunitaria bastaría con una segunda fuente de datos y una nueva pestaña, sin tocar el editor ni el reproductor.

## Pendiente para próximas versiones

- Icono de la app y textos en `strings.xml` (ahora están en el código, en español).
- Tests, ProGuard/R8 y firma de la APK de release.
- Pruebas en varios fabricantes: algunos (Samsung, Xiaomi) gestionan los tonos de forma propia.
